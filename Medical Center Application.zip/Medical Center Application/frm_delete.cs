﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Medical_Center_Application
{
    public partial class frm_delete : Form
    {
        SqlConnection sc = new SqlConnection("Server=DESKTOP-KB5MUUG;DataBase=Patients;Integrated Security=true;");
        SqlCommand cmd;
        public frm_delete()
        {
            InitializeComponent();
        }

        private void frm_delete_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
            cmd =new SqlCommand("Delete From Reports_of_Patients Where National_id="+textBox1.Text+"",sc);
                sc.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Delete successfully", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sc.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.OpenForms[1].Show();
            this.Close();
        }
    }
}
