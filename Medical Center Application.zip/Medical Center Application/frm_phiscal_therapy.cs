﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Medical_Center_Application
{
    public partial class frm_phiscal_therapy : Form
    {
        public frm_phiscal_therapy()
        {
            InitializeComponent();
        }

        private void roundbutton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.OpenForms[0].Show();
            this.Close();
        }

        private void roundbutton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton6_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton8_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton7_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton5_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }
    }
}
