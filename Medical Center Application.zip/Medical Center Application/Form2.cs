﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Medical_Center_Application
{
    public partial class frm_register : Form
    {
        SqlConnection sc = new SqlConnection("Server=DESKTOP-KB5MUUG;DataBase=Patients;Integrated Security=true;");
        SqlCommand cmd;
        SqlDataAdapter da;
        string str="male";
        public frm_register()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.OpenForms[1].Show();
            this.Close();

        }

        private void frm_register_Load(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            sc.Open();
            MessageBox.Show("connection is : " + sc.State);
            sc.Close();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                cmd = new SqlCommand("Insert into Reports_of_Patients (Name, Address, National_id, Telephone, Gender, Diseases, Examine_date, Age)Values('" + txtname.Text + "','" + txtaddr.Text + "'," + txtid.Text + "," + txttele.Text + ",'" + str + "','" + txtdiseases.Text + "','" + dateTimePicker1.Value + "'," + txtage.Text + ")", sc);
                sc.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("add successfully", "add", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                MessageBox.Show("The Date that you have set for the medical examination is the date of examining another patient. please change the date of  the medical examination.    OR    " +ex.Message, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                sc.Close();
            }

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
             str="male";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
         str="female";
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            da = new SqlDataAdapter("Select * From Reports_of_Patients where Examine_date='" + dateTimePicker1.Value + "' ", sc);
            frm_print frm = new frm_print();
            da.Fill(frm.PatientsDataSet.Reports_of_Patients);
            frm.reportViewer1.RefreshReport();
            frm.Show();
        }

        private void txtname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
