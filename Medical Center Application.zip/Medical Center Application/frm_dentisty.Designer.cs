﻿namespace Medical_Center_Application
{
    partial class frm_dentisty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.roundbutton4 = new Medical_Center_Application.roundbutton();
            this.roundbutton3 = new Medical_Center_Application.roundbutton();
            this.roundbutton2 = new Medical_Center_Application.roundbutton();
            this.roundbutton1 = new Medical_Center_Application.roundbutton();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button1.Location = new System.Drawing.Point(33, 502);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 33);
            this.button1.TabIndex = 10;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Crimson;
            this.label1.Location = new System.Drawing.Point(202, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(312, 37);
            this.label1.TabIndex = 11;
            this.label1.Text = "Dental Department ";
            // 
            // roundbutton4
            // 
            this.roundbutton4.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0049;
            this.roundbutton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton4.ForeColor = System.Drawing.Color.DarkRed;
            this.roundbutton4.Location = new System.Drawing.Point(90, 319);
            this.roundbutton4.Name = "roundbutton4";
            this.roundbutton4.Size = new System.Drawing.Size(170, 159);
            this.roundbutton4.TabIndex = 3;
            this.roundbutton4.Text = "Peiatric, Orthodontics and Preventive ";
            this.roundbutton4.UseVisualStyleBackColor = true;
            this.roundbutton4.Click += new System.EventHandler(this.roundbutton4_Click);
            // 
            // roundbutton3
            // 
            this.roundbutton3.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0054;
            this.roundbutton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton3.Location = new System.Drawing.Point(438, 319);
            this.roundbutton3.Name = "roundbutton3";
            this.roundbutton3.Size = new System.Drawing.Size(170, 159);
            this.roundbutton3.TabIndex = 2;
            this.roundbutton3.Text = "Removable Prosthodontics";
            this.roundbutton3.UseVisualStyleBackColor = true;
            this.roundbutton3.Click += new System.EventHandler(this.roundbutton3_Click);
            // 
            // roundbutton2
            // 
            this.roundbutton2.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0055;
            this.roundbutton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton2.Location = new System.Drawing.Point(438, 103);
            this.roundbutton2.Name = "roundbutton2";
            this.roundbutton2.Size = new System.Drawing.Size(170, 159);
            this.roundbutton2.TabIndex = 1;
            this.roundbutton2.Text = "Conservative Dentisty";
            this.roundbutton2.UseVisualStyleBackColor = true;
            this.roundbutton2.Click += new System.EventHandler(this.roundbutton2_Click);
            // 
            // roundbutton1
            // 
            this.roundbutton1.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0052;
            this.roundbutton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton1.ForeColor = System.Drawing.Color.Cornsilk;
            this.roundbutton1.Location = new System.Drawing.Point(90, 103);
            this.roundbutton1.Name = "roundbutton1";
            this.roundbutton1.Size = new System.Drawing.Size(170, 159);
            this.roundbutton1.TabIndex = 0;
            this.roundbutton1.Text = "Oral Medicine and  Periodontology";
            this.roundbutton1.UseVisualStyleBackColor = true;
            this.roundbutton1.Click += new System.EventHandler(this.roundbutton1_Click);
            // 
            // frm_dentisty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0048;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(749, 547);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.roundbutton4);
            this.Controls.Add(this.roundbutton3);
            this.Controls.Add(this.roundbutton2);
            this.Controls.Add(this.roundbutton1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frm_dentisty";
            this.Text = "frm_dentisty";
            this.Load += new System.EventHandler(this.frm_dentisty_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private roundbutton roundbutton1;
        private roundbutton roundbutton2;
        private roundbutton roundbutton3;
        private roundbutton roundbutton4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}