﻿namespace Medical_Center_Application
{
    partial class frm_phiscal_therapy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.roundbutton8 = new Medical_Center_Application.roundbutton();
            this.roundbutton7 = new Medical_Center_Application.roundbutton();
            this.roundbutton6 = new Medical_Center_Application.roundbutton();
            this.roundbutton5 = new Medical_Center_Application.roundbutton();
            this.roundbutton4 = new Medical_Center_Application.roundbutton();
            this.roundbutton3 = new Medical_Center_Application.roundbutton();
            this.roundbutton2 = new Medical_Center_Application.roundbutton();
            this.roundbutton1 = new Medical_Center_Application.roundbutton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(143, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(503, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Department of Physical Therapy";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.button1.Location = new System.Drawing.Point(50, 457);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 33);
            this.button1.TabIndex = 9;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // roundbutton8
            // 
            this.roundbutton8.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0058;
            this.roundbutton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton8.Location = new System.Drawing.Point(33, 229);
            this.roundbutton8.Name = "roundbutton8";
            this.roundbutton8.Size = new System.Drawing.Size(152, 124);
            this.roundbutton8.TabIndex = 8;
            this.roundbutton8.Text = "Burns and Deformities";
            this.roundbutton8.UseVisualStyleBackColor = true;
            this.roundbutton8.Click += new System.EventHandler(this.roundbutton8_Click);
            // 
            // roundbutton7
            // 
            this.roundbutton7.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0057;
            this.roundbutton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton7.Location = new System.Drawing.Point(222, 229);
            this.roundbutton7.Name = "roundbutton7";
            this.roundbutton7.Size = new System.Drawing.Size(152, 124);
            this.roundbutton7.TabIndex = 7;
            this.roundbutton7.Text = "Nutrition, Obesity and Thiness";
            this.roundbutton7.UseVisualStyleBackColor = true;
            this.roundbutton7.Click += new System.EventHandler(this.roundbutton7_Click);
            // 
            // roundbutton6
            // 
            this.roundbutton6.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0031;
            this.roundbutton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton6.Location = new System.Drawing.Point(222, 87);
            this.roundbutton6.Name = "roundbutton6";
            this.roundbutton6.Size = new System.Drawing.Size(152, 124);
            this.roundbutton6.TabIndex = 6;
            this.roundbutton6.Text = "for Children";
            this.roundbutton6.UseVisualStyleBackColor = true;
            this.roundbutton6.Click += new System.EventHandler(this.roundbutton6_Click);
            // 
            // roundbutton5
            // 
            this.roundbutton5.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0062;
            this.roundbutton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton5.Location = new System.Drawing.Point(596, 229);
            this.roundbutton5.Name = "roundbutton5";
            this.roundbutton5.Size = new System.Drawing.Size(152, 124);
            this.roundbutton5.TabIndex = 5;
            this.roundbutton5.Text = "Playground injuries ";
            this.roundbutton5.UseVisualStyleBackColor = true;
            this.roundbutton5.Click += new System.EventHandler(this.roundbutton5_Click);
            // 
            // roundbutton4
            // 
            this.roundbutton4.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0060;
            this.roundbutton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton4.ForeColor = System.Drawing.Color.Coral;
            this.roundbutton4.Location = new System.Drawing.Point(596, 87);
            this.roundbutton4.Name = "roundbutton4";
            this.roundbutton4.Size = new System.Drawing.Size(152, 124);
            this.roundbutton4.TabIndex = 4;
            this.roundbutton4.Text = "Bones and Joints";
            this.roundbutton4.UseVisualStyleBackColor = true;
            this.roundbutton4.Click += new System.EventHandler(this.roundbutton4_Click);
            // 
            // roundbutton3
            // 
            this.roundbutton3.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0064;
            this.roundbutton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton3.Location = new System.Drawing.Point(404, 229);
            this.roundbutton3.Name = "roundbutton3";
            this.roundbutton3.Size = new System.Drawing.Size(152, 124);
            this.roundbutton3.TabIndex = 3;
            this.roundbutton3.Text = "Internal Medicine ";
            this.roundbutton3.UseVisualStyleBackColor = true;
            this.roundbutton3.Click += new System.EventHandler(this.roundbutton3_Click);
            // 
            // roundbutton2
            // 
            this.roundbutton2.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0034;
            this.roundbutton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton2.ForeColor = System.Drawing.Color.Crimson;
            this.roundbutton2.Location = new System.Drawing.Point(404, 87);
            this.roundbutton2.Name = "roundbutton2";
            this.roundbutton2.Size = new System.Drawing.Size(152, 124);
            this.roundbutton2.TabIndex = 2;
            this.roundbutton2.Text = "Neurologists";
            this.roundbutton2.UseVisualStyleBackColor = true;
            this.roundbutton2.Click += new System.EventHandler(this.roundbutton2_Click);
            // 
            // roundbutton1
            // 
            this.roundbutton1.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0025;
            this.roundbutton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton1.Location = new System.Drawing.Point(33, 87);
            this.roundbutton1.Name = "roundbutton1";
            this.roundbutton1.Size = new System.Drawing.Size(152, 124);
            this.roundbutton1.TabIndex = 1;
            this.roundbutton1.Text = "Obstetrics and Gynecology";
            this.roundbutton1.UseVisualStyleBackColor = true;
            this.roundbutton1.Click += new System.EventHandler(this.roundbutton1_Click);
            // 
            // frm_phiscal_therapy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0061;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(848, 502);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.roundbutton8);
            this.Controls.Add(this.roundbutton7);
            this.Controls.Add(this.roundbutton6);
            this.Controls.Add(this.roundbutton5);
            this.Controls.Add(this.roundbutton4);
            this.Controls.Add(this.roundbutton3);
            this.Controls.Add(this.roundbutton2);
            this.Controls.Add(this.roundbutton1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frm_phiscal_therapy";
            this.Text = "frm_phiscal_therapy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private roundbutton roundbutton1;
        private roundbutton roundbutton2;
        private roundbutton roundbutton3;
        private roundbutton roundbutton4;
        private roundbutton roundbutton5;
        private roundbutton roundbutton6;
        private roundbutton roundbutton7;
        private roundbutton roundbutton8;
        private System.Windows.Forms.Button button1;
    }
}