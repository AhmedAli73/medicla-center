﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Medical_Center_Application
{
    public partial class frm_humanmedicine : Form
    {
        public frm_humanmedicine()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.OpenForms[0].Show();
            this.Close();
        }

        private void roundbutton3_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton7_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();
        }

        private void roundbutton13_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();

        }

        private void roundbutton6_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();

        }

        private void roundbutton5_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();

        }

        private void roundbutton8_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();

        }

        private void roundbutton10_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();

        }

        private void roundbutton9_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();

        }

        private void roundbutton14_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();

        }

        private void roundbutton12_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();

        }

        private void roundbutton11_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm_register frm1 = new frm_register();
            frm1.Show();

        }
    }
}
