﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Medical_Center_Application
{
    public partial class frm_search : Form
    {
        SqlConnection sc = new SqlConnection("Server=DESKTOP-KB5MUUG;DataBase=Patients;Integrated Security=true;");
        SqlDataAdapter da;
        DataTable dt = new DataTable();

        public frm_search()
        {
            InitializeComponent();
            da = new SqlDataAdapter("select * From Reports_of_Patients", sc);
            da.Fill(dt);
            this.dataGridView1.DataSource = dt;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dt.Clear();
            da = new SqlDataAdapter("select * From Reports_of_Patients where Name+ Address+ convert(varchar,National_id)+convert(varchar,Telephone)+Gender +Diseases + Examine_date +convert(varchar,Age) like '%"+textBox1.Text+"%'", sc);

            da.Fill(dt);
            this.dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frm_print frm = new frm_print();
            frm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            da = new SqlDataAdapter("Select * From Reports_of_Patients where Examine_date='"+dataGridView1.CurrentRow.Cells[6].Value+"' ", sc);
            frm_print frm = new frm_print();
            da.Fill(frm.PatientsDataSet.Reports_of_Patients);
            frm.reportViewer1.RefreshReport();
            frm.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
