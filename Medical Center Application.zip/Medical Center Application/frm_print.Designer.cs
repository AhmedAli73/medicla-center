﻿namespace Medical_Center_Application
{
    partial class frm_print
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.PatientsDataSet = new Medical_Center_Application.PatientsDataSet();
            this.Reports_of_PatientsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Reports_of_PatientsTableAdapter = new Medical_Center_Application.PatientsDataSetTableAdapters.Reports_of_PatientsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.PatientsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Reports_of_PatientsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.Reports_of_PatientsBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Medical_Center_Application.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(984, 564);
            this.reportViewer1.TabIndex = 0;
            // 
            // PatientsDataSet
            // 
            this.PatientsDataSet.DataSetName = "PatientsDataSet";
            this.PatientsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Reports_of_PatientsBindingSource
            // 
            this.Reports_of_PatientsBindingSource.DataMember = "Reports_of_Patients";
            this.Reports_of_PatientsBindingSource.DataSource = this.PatientsDataSet;
            // 
            // Reports_of_PatientsTableAdapter
            // 
            this.Reports_of_PatientsTableAdapter.ClearBeforeFill = true;
            // 
            // frm_print
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 564);
            this.Controls.Add(this.reportViewer1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frm_print";
            this.Text = "frm_print";
            this.Load += new System.EventHandler(this.frm_print_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PatientsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Reports_of_PatientsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource Reports_of_PatientsBindingSource;
        private PatientsDataSetTableAdapters.Reports_of_PatientsTableAdapter Reports_of_PatientsTableAdapter;
        public Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        public PatientsDataSet PatientsDataSet;
    }
}