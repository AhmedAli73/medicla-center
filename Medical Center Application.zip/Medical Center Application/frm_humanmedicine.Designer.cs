﻿namespace Medical_Center_Application
{
    partial class frm_humanmedicine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.roundbutton14 = new Medical_Center_Application.roundbutton();
            this.roundbutton13 = new Medical_Center_Application.roundbutton();
            this.roundbutton12 = new Medical_Center_Application.roundbutton();
            this.roundbutton11 = new Medical_Center_Application.roundbutton();
            this.roundbutton10 = new Medical_Center_Application.roundbutton();
            this.roundbutton9 = new Medical_Center_Application.roundbutton();
            this.roundbutton8 = new Medical_Center_Application.roundbutton();
            this.roundbutton7 = new Medical_Center_Application.roundbutton();
            this.roundbutton6 = new Medical_Center_Application.roundbutton();
            this.roundbutton5 = new Medical_Center_Application.roundbutton();
            this.roundbutton4 = new Medical_Center_Application.roundbutton();
            this.roundbutton3 = new Medical_Center_Application.roundbutton();
            this.roundbutton2 = new Medical_Center_Application.roundbutton();
            this.roundbutton1 = new Medical_Center_Application.roundbutton();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OliveDrab;
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(24, 508);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 37);
            this.button1.TabIndex = 0;
            this.button1.Text = "back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(140, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(534, 39);
            this.label1.TabIndex = 1;
            this.label1.Text = "Department of Human Medicine";
            // 
            // roundbutton14
            // 
            this.roundbutton14.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton14.Location = new System.Drawing.Point(24, 362);
            this.roundbutton14.Name = "roundbutton14";
            this.roundbutton14.Size = new System.Drawing.Size(147, 112);
            this.roundbutton14.TabIndex = 15;
            this.roundbutton14.Text = "Liver diseases";
            this.roundbutton14.UseVisualStyleBackColor = false;
            this.roundbutton14.Click += new System.EventHandler(this.roundbutton14_Click);
            // 
            // roundbutton13
            // 
            this.roundbutton13.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton13.Location = new System.Drawing.Point(186, 362);
            this.roundbutton13.Name = "roundbutton13";
            this.roundbutton13.Size = new System.Drawing.Size(147, 112);
            this.roundbutton13.TabIndex = 14;
            this.roundbutton13.Text = "General Surgery";
            this.roundbutton13.UseVisualStyleBackColor = false;
            this.roundbutton13.Click += new System.EventHandler(this.roundbutton13_Click);
            // 
            // roundbutton12
            // 
            this.roundbutton12.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton12.Location = new System.Drawing.Point(351, 362);
            this.roundbutton12.Name = "roundbutton12";
            this.roundbutton12.Size = new System.Drawing.Size(147, 112);
            this.roundbutton12.TabIndex = 13;
            this.roundbutton12.Text = "Slimming and nutrition";
            this.roundbutton12.UseVisualStyleBackColor = false;
            this.roundbutton12.Click += new System.EventHandler(this.roundbutton12_Click);
            // 
            // roundbutton11
            // 
            this.roundbutton11.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton11.Location = new System.Drawing.Point(527, 362);
            this.roundbutton11.Name = "roundbutton11";
            this.roundbutton11.Size = new System.Drawing.Size(147, 112);
            this.roundbutton11.TabIndex = 12;
            this.roundbutton11.Text = "Plastic surgery";
            this.roundbutton11.UseVisualStyleBackColor = false;
            this.roundbutton11.Click += new System.EventHandler(this.roundbutton11_Click);
            // 
            // roundbutton10
            // 
            this.roundbutton10.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton10.Location = new System.Drawing.Point(516, 225);
            this.roundbutton10.Name = "roundbutton10";
            this.roundbutton10.Size = new System.Drawing.Size(146, 112);
            this.roundbutton10.TabIndex = 11;
            this.roundbutton10.Text = "Tumors";
            this.roundbutton10.UseVisualStyleBackColor = false;
            this.roundbutton10.Click += new System.EventHandler(this.roundbutton10_Click);
            // 
            // roundbutton9
            // 
            this.roundbutton9.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton9.Location = new System.Drawing.Point(681, 225);
            this.roundbutton9.Name = "roundbutton9";
            this.roundbutton9.Size = new System.Drawing.Size(151, 112);
            this.roundbutton9.TabIndex = 10;
            this.roundbutton9.Text = "kidnay diseases";
            this.roundbutton9.UseVisualStyleBackColor = false;
            this.roundbutton9.Click += new System.EventHandler(this.roundbutton9_Click);
            // 
            // roundbutton8
            // 
            this.roundbutton8.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton8.BackgroundImage = global::Medical_Center_Application.Properties.Resources._0;
            this.roundbutton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton8.Location = new System.Drawing.Point(347, 225);
            this.roundbutton8.Name = "roundbutton8";
            this.roundbutton8.Size = new System.Drawing.Size(151, 112);
            this.roundbutton8.TabIndex = 9;
            this.roundbutton8.Text = "Skin diseases";
            this.roundbutton8.UseVisualStyleBackColor = false;
            this.roundbutton8.Click += new System.EventHandler(this.roundbutton8_Click);
            // 
            // roundbutton7
            // 
            this.roundbutton7.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton7.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0040;
            this.roundbutton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton7.Location = new System.Drawing.Point(186, 95);
            this.roundbutton7.Name = "roundbutton7";
            this.roundbutton7.Size = new System.Drawing.Size(145, 115);
            this.roundbutton7.TabIndex = 8;
            this.roundbutton7.Text = "Neurologists";
            this.roundbutton7.UseVisualStyleBackColor = false;
            this.roundbutton7.Click += new System.EventHandler(this.roundbutton7_Click);
            // 
            // roundbutton6
            // 
            this.roundbutton6.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton6.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0059;
            this.roundbutton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton6.ForeColor = System.Drawing.Color.AliceBlue;
            this.roundbutton6.Location = new System.Drawing.Point(24, 225);
            this.roundbutton6.Name = "roundbutton6";
            this.roundbutton6.Size = new System.Drawing.Size(147, 112);
            this.roundbutton6.TabIndex = 7;
            this.roundbutton6.Text = "Bones and Joints";
            this.roundbutton6.UseVisualStyleBackColor = false;
            this.roundbutton6.Click += new System.EventHandler(this.roundbutton6_Click);
            // 
            // roundbutton5
            // 
            this.roundbutton5.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton5.Location = new System.Drawing.Point(186, 225);
            this.roundbutton5.Name = "roundbutton5";
            this.roundbutton5.Size = new System.Drawing.Size(145, 112);
            this.roundbutton5.TabIndex = 6;
            this.roundbutton5.Text = "Babies and newborns";
            this.roundbutton5.UseVisualStyleBackColor = false;
            this.roundbutton5.Click += new System.EventHandler(this.roundbutton5_Click);
            // 
            // roundbutton4
            // 
            this.roundbutton4.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton4.Location = new System.Drawing.Point(516, 95);
            this.roundbutton4.Name = "roundbutton4";
            this.roundbutton4.Size = new System.Drawing.Size(146, 115);
            this.roundbutton4.TabIndex = 5;
            this.roundbutton4.Text = "Heart diseases";
            this.roundbutton4.UseVisualStyleBackColor = false;
            this.roundbutton4.Click += new System.EventHandler(this.roundbutton4_Click);
            // 
            // roundbutton3
            // 
            this.roundbutton3.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton3.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0056;
            this.roundbutton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.roundbutton3.Location = new System.Drawing.Point(347, 95);
            this.roundbutton3.Name = "roundbutton3";
            this.roundbutton3.Size = new System.Drawing.Size(151, 115);
            this.roundbutton3.TabIndex = 4;
            this.roundbutton3.Text = "Interior";
            this.roundbutton3.UseVisualStyleBackColor = false;
            this.roundbutton3.Click += new System.EventHandler(this.roundbutton3_Click);
            // 
            // roundbutton2
            // 
            this.roundbutton2.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton2.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0045;
            this.roundbutton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.roundbutton2.ForeColor = System.Drawing.Color.Black;
            this.roundbutton2.Location = new System.Drawing.Point(681, 95);
            this.roundbutton2.Name = "roundbutton2";
            this.roundbutton2.Size = new System.Drawing.Size(151, 115);
            this.roundbutton2.TabIndex = 3;
            this.roundbutton2.Text = "Ear, Nose and Throat ";
            this.roundbutton2.UseVisualStyleBackColor = false;
            this.roundbutton2.Click += new System.EventHandler(this.roundbutton2_Click);
            // 
            // roundbutton1
            // 
            this.roundbutton1.BackColor = System.Drawing.Color.RosyBrown;
            this.roundbutton1.BackgroundImage = global::Medical_Center_Application.Properties.Resources.IMG_20200917_WA0025;
            this.roundbutton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.roundbutton1.ForeColor = System.Drawing.Color.Black;
            this.roundbutton1.Location = new System.Drawing.Point(24, 95);
            this.roundbutton1.Name = "roundbutton1";
            this.roundbutton1.Size = new System.Drawing.Size(147, 115);
            this.roundbutton1.TabIndex = 2;
            this.roundbutton1.Text = "Obstetrics and Gynecology";
            this.roundbutton1.UseVisualStyleBackColor = false;
            this.roundbutton1.Click += new System.EventHandler(this.roundbutton1_Click);
            // 
            // frm_humanmedicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Medical_Center_Application.Properties.Resources.bg;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(856, 557);
            this.Controls.Add(this.roundbutton14);
            this.Controls.Add(this.roundbutton13);
            this.Controls.Add(this.roundbutton12);
            this.Controls.Add(this.roundbutton11);
            this.Controls.Add(this.roundbutton10);
            this.Controls.Add(this.roundbutton9);
            this.Controls.Add(this.roundbutton8);
            this.Controls.Add(this.roundbutton7);
            this.Controls.Add(this.roundbutton6);
            this.Controls.Add(this.roundbutton5);
            this.Controls.Add(this.roundbutton4);
            this.Controls.Add(this.roundbutton3);
            this.Controls.Add(this.roundbutton2);
            this.Controls.Add(this.roundbutton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.SeaGreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frm_humanmedicine";
            this.Text = "Medical Center Application ";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private roundbutton roundbutton1;
        private roundbutton roundbutton2;
        private roundbutton roundbutton3;
        private roundbutton roundbutton4;
        private roundbutton roundbutton5;
        private roundbutton roundbutton6;
        private roundbutton roundbutton7;
        private roundbutton roundbutton8;
        private roundbutton roundbutton9;
        private roundbutton roundbutton10;
        private roundbutton roundbutton11;
        private roundbutton roundbutton12;
        private roundbutton roundbutton13;
        private roundbutton roundbutton14;
    }
}